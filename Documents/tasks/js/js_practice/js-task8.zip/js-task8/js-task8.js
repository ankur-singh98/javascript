 var html = "<h1>Shopping Site</h1>";
 
//  <img src='a1.webp' ><div><h1>White 350rs <button  class='btn1' >Add Cart</button></h1></div></div><div ><img src='a6.jpg' ><div><h1>450 <button class='btn1'>Add Cart</button></h1></div></div><div ><img src='a4.jpg' ><div><h1>300 <button class='btn1'>Add Cart</button></h1></div>  </div></div>";


var mainarr = [
    {
id :1,
name : "White_shoe",
price : "350rs",
img : "a1.webp",
btn :"Add ToCart"
},
{
    id :2,
    name : "Sports_shoe",
    price : "450rs",
    img : "a6.jpg",
    btn :"Add ToCart"
    
},
{
    id :3,
    name : "Light_shoe",
    price : "300rs",
    img : "a4.jpg",
    btn :"Add ToCart"
}
];

var newarr = mainarr.map(x => ` <div><img src='${x.img}'><div><h1>${x.name} <button onclick="myfun(event)" class='${x.id}' >${x.btn}</button></h1></div></div>`);

html +="<div id='main'>"+ newarr+"</div >";
html += "<h1>Cart</h1>";
document.write(html);
 var count = 0;
var html1= "<table  id='cart' border='1'><tr><th>Name</th><th>Image</th><th>Price</th><th>Quantity</th></tr> "
function myfun(event)
{
    
     var element = document.getElementById("cart");
    var dup = document.getElementsByClassName("Cart_item")[0];
    var x = event.target;
   var id = x.className;
   for(var i = 0;i<mainarr.length; i++)
   {
    if(mainarr[i].id == id)
    {
        count =count+1;
        // duplicacy
        var cartitem = dup.getElementsByClassName("cart_name");
        for(var i = 0;i<cartitem.length;i++)
        {
            if(cartitem[i].innerHTML == mainarr[i].name)
            {
alert("already");
            }
        }
// console.log(mainarr[i].name);
var abb = "<tr class='cart_item' ><td class='cart_name'>"+mainarr[i].name+"</td><td><img src='"+mainarr[i].img+"'></td><td>"+mainarr[i].price+"</td><td>"+count+"</td><tr></table>";
element.innerHTML += abb;

    }
// let uniqueChars = [];
// mainarr.forEach((id) => {
//     if (!uniqueChars.includes(id)) {
//         uniqueChars.push(id);
//     }
// });

// console.log(uniqueChars);
   }
   

}
document.write(html1);


// html += newarr;
// console.log(newarr);

// function pro1()
// {
// var a= mainarr.length;
// for(var i in main)
// {
//     // for(var j = 0;j<=mainarr[i];j++)
//     // {
//         var l=  mainarr[i].id;
//         if(l == 1)
//         {
//             alert("hii");
//         }
      
//     // }

// }

// }
// html += "<div id='main'><div ><img src='a2.png' ><div><h1>Yellow Shoe 450rs <button >Add Cart</button></h1></div></div><div ><img src='a5.jpeg' ><div><h1>650 <button >Add Cart</button></h1></div></div><div ><img src='a3.jpg' ><div><h1>550 <button >Add Cart</button></h1></div>  </div></div>";


