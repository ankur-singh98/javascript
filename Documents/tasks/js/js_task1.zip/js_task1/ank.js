


// window.alert("hello");
 var f_name = "Gaurav";
var l_name =  " Mandhyan";
var full = f_name + l_name;
 var total = f_name.length + l_name.length;
 var subtotal = total * 5;
 var grand = subtotal + 7;
 // window.alert(grand);
var html = "<h1>Order Details</h1>";
html+= "<p>Hello " + f_name +" , please check your order</p>";
 html += "<table border='1'> <tr> <td>Name</td><td> " +full+ " </td></tr><tr><td>Total Letters</td><td>" +total+ "</td></tr><tr><td>Subtotal</td><td> $" + subtotal+ "</td></tr><tr><td>Shipping</td><td>$7</td></tr><tr><td>Grand total</td><td>$" + grand+ "</td></tr></table>";
html += "<a href=''> pay now </a>";
 document.write(html);
// document.write("<h1>Order Details</h1>");
// document.write("<p>Hello Gaurav, please check your order</p>");
// document.write("<table border='1'>");

// document.write("<tr>");
// document.write("<td>Name</td>");
// document.write("<td>1</td>");
// document.write("</tr>");


// document.write("<tr>");
// document.write("<td>Grand Total</td>");
// document.write("<tr>");
// document.write("<td>Total letters</td>");
// document.write("<td>1</td>");
// document.write("</tr>");

// document.write("<tr>");
// document.write("<td>Subtotal</td>");

// document.write("<td>"+subtotal+"</td>");
// document.write("</tr>");

// document.write("<tr>");
// document.write("<td>Shipping</td>");
// document.write("<td>1</td>");
// document.write("</tr>");

// document.write("<tr>");
// document.write("<td>Grand Total</td>");
// document.write("<td>1</td>");
// document.write("</tr>");

// document.write("</table>");
